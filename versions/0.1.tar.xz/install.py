run("cp /tmp/vet/vet.py /py/vet.py")
